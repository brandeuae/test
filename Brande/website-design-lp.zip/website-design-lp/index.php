<?php

header('Content-Type: text/html; charset=utf-8');

// Check if User Coming From A Request
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

	// Assign Variables
	$user = filter_var($_POST['username'], FILTER_SANITIZE_STRING);
	$mail = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
	$cell = filter_var($_POST['cellphone'], FILTER_SANITIZE_NUMBER_INT);
	// $msg  = filter_var($_POST['message'], FILTER_SANITIZE_STRING);

	// Creating Array of Errors
	$formErrors = array();
	// if (strlen($user) <= 3) {
	//     $formErrors[] = 'Username Must Be Larger Than <strong>3</strong> Characters';
	// }
	// if (strlen($msg) < 10) {
	//     $formErrors[] = 'Message Can\'t Be Less Than <strong>10</strong> Characters'; 
	// }

	// If No Errors Send The Email [ mail(To, Subject, Message, Headers, Parameters) ]

	$headers = "From: $mail \r\n";
	$headers .= "Name: $user \r\n";
	$headers .= "Phone: $cell \r\n";
	$myEmail = 'm.tartouri@brande.ae';
	$subject = 'Contact Form';

	if (empty($formErrors)) {

		mail($myEmail, $subject, $headers);

		$user = '';
		$mail = '';
		$cell = '';
		// $msg = '';

		$success = '<div class="alert alert-success">تم استلام رسالتك بنجاح، وسيتم التواصل معك في أقرب وقت.</div>';
	}
}
?>

<!DOCTYPE html>
<html >

<head>
	<meta charset="UTF-8" />
	<title>تصميم وتطوير المواقع الالكترونية - براندي</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="description" content="it's all about branding">
	<link rel="stylesheet" type="text/css" href="style-ar.css">
</head>

<body>

	<header id="site_header">
		<div class="container">
			<div class="row">
				<div class="col l2 m3 s12" data-sal="slide-up" data-sal-duration="500" data-sal-delay="100">
					<a href="#main_slider" class="logo">
						<img src="img/Brande-Logo.png">
					</a>
				</div>

				<div class="col l10 m9 s12">
					<div class="mai_menu right-align">
						<ul class="inline-block">
							<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="100"><a href="#main_slider">الرئيسية</a></li>
							<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="200"><a href="#oklsdi">خدمات الويب</a></li>
							<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="300"><a href="#free_offer">عروض الويب</a></li>
							<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="400"><a href="#about_us">من نحن</a></li>
							<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="500"><a href="#get_touch">اتصل بنا</a></li>
							<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="600"><a href="javascript:void(0);" id="new_proj">دعنا نناقش الافكار</a></li>

						</ul>
					</div>
				</div>


			</div>
		</div>
	</header>


	<div class="hes_dkle"><svg xmlns="http://www.w3.org/2000/svg" width="10" height="404" viewBox="0 0 10 404">
			<path fill="#02cab7" d="M0,0H10a0,0,0,0,1,0,0V394A10,10,0,0,1,0,404H0a0,0,0,0,1,0,0V0A0,0,0,0,1,0,0Z"></path>
		</svg></div>

	<section id="main_slider">
		<div class="container">
			<div class="row">
				<div class="col l7 m7 s12">
					<div class="alsdke_s">
						<div class="heading">
							<h1 data-sal="slide-up" data-sal-duration="500" data-sal-delay="100">قم بإنشاء موقعك الالكتروني </h1>
							<p data-sal="slide-up" data-sal-duration="500" data-sal-delay="300">نقدم مجموعة واسعة من خدمات تطوير وتصميم المواقع الالكترونية التي ستساعدك على وضع عملك على الخريطة والبدء في تحقيق النمو والأرباح.
							</p>
						</div>

						<div class="def_btn" data-sal="slide-up" data-sal-duration="500" data-sal-delay="200">
							<a href="javascript:void(0);">
								<span>دعنا نتحدث اليوم</span>
							</a>
						</div>
					</div><!-- alsdke_s -->
				</div>

				<div class="col l5 m5 s12 hide-on-small-only">
					<div class="dakljrer" data-sal="fade" data-sal-duration="500" data-sal-delay="300">
						<img src="img/sapiens he.svg">
					</div>
				</div>
			</div>
		</div>
	</section>


	<section id="free_offer">
		<div class="container">
			<div class="row">
				<div class="col l6 m6 s12 hide-on-small-only" data-sal="slide-up" data-sal-duration="500" data-sal-delay="100">
					<img src="img/sapiens_fd.svg">
				</div>

				<div class="col l6 m6 s12">
					<div class="alsdkje_sd">
						<div class="tit_le" data-sal="slide-up" data-sal-duration="500" data-sal-delay="300">
							<div class="lkasjdw">عرضنا</div>
							<h1>استمتع بثلاثة أشهر مجانية من صيانة الموقع
							</h1>
						</div>

						<div class="def_btn" data-sal="slide-up" data-sal-duration="500" data-sal-delay="200">
							<a href="javascript:void(0);">
								<span>ابدأ الآن</span>
							</a>
						</div>
					</div><!-- alsdkje_sd -->
				</div>
			</div>
		</div>
	</section>



	<div class="container">
		<div class="row">



		</div>
	</div>




	<section id="our_works">
		<div class="container">
			<div class="row">
				<div class="col l7 m12 s12">

					<div class="tit_le hide-on-large-only show-on-medium-and-down" data-sal="slide-up" data-sal-duration="500" data-sal-delay="300">
						<div class="lkasjdw">اعمالنا</div>
						<h1>النتائج التي تجعلك سعيدا!
						</h1>
					</div>


					<div class="lkasdoe clearfix">

						<div class="tab-content" data-tab="1">
							<img src="img/kids.jpg">
						</div>

						<div class="tab-content" data-tab="2">
							<img src="img/cl_sl.png">
						</div>

						<div class="tab-content" data-tab="3">
							<img src="img/85b84598175927.Y3JvcCw4MDgsNjMyLDAsMA.png">
						</div>

						<div class="tab-content" data-tab="4">
							<img src="img/0d938198177857.Y3JvcCw4MDgsNjMyLDAsMA.png">
						</div>

						<div class="tab-content" data-tab="5">
							<img src="img/93f5b698176757.Y3JvcCw4MDgsNjMyLDAsMA.png">
						</div>

					</div>
				</div>

				<div class="col l5 m12 s12">
					<div class="asdwpofd">

						<div class="tit_le hide-on-med-and-down" data-sal="slide-up" data-sal-duration="500" data-sal-delay="300">
							<div class="lkasjdw">اعمالنا</div>
							<h1>النتائج التي تجعلك سعيدا!
							</h1>
						</div>


						<div id="wrap">

							<div class="container">
								<div class="tabs">

									<ul>

										<li class="asd" data-tab="1">
											<input type="radio" id="tab1" name="tabs" checked />
											<label class="tab selected" for="tab1">
												<svg xmlns="http://www.w3.org/2000/svg" width="17.662" height="19.708" viewBox="0 0 17.662 19.708">
													<path d="M-380.03-1782.005a7.881,7.881,0,0,1,7.873-7.872,7.882,7.882,0,0,1,7.873,7.872,7.882,7.882,0,0,1-7.873,7.873A7.882,7.882,0,0,1-380.03-1782.005Zm3.766,0a4.111,4.111,0,0,0,4.107,4.107,4.111,4.111,0,0,0,4.107-4.107,4.111,4.111,0,0,0-4.107-4.107A4.111,4.111,0,0,0-376.264-1782.005Zm-4.682-7.925v-2.91h3.767v2.91Z" transform="translate(381.446 1793.341)" />
												</svg>
												<div class="cli_name">Kids DXB</div>
											</label>
										</li>

										<li class="asd" data-tab="2">
											<input type="radio" id="tab2" name="tabs" />
											<label class="tab" for="tab2">
												<svg xmlns="http://www.w3.org/2000/svg" width="17.662" height="19.708" viewBox="0 0 17.662 19.708">
													<path d="M-380.03-1782.005a7.881,7.881,0,0,1,7.873-7.872,7.882,7.882,0,0,1,7.873,7.872,7.882,7.882,0,0,1-7.873,7.873A7.882,7.882,0,0,1-380.03-1782.005Zm3.766,0a4.111,4.111,0,0,0,4.107,4.107,4.111,4.111,0,0,0,4.107-4.107,4.111,4.111,0,0,0-4.107-4.107A4.111,4.111,0,0,0-376.264-1782.005Zm-4.682-7.925v-2.91h3.767v2.91Z" transform="translate(381.446 1793.341)" />
												</svg>
												<div class="cli_name">DM Consultant</div>
											</label>
										</li>

										<li class="asd" data-tab="3">
											<input type="radio" id="tab3" name="tabs" />
											<label class="tab" for="tab3">
												<svg xmlns="http://www.w3.org/2000/svg" width="17.662" height="19.708" viewBox="0 0 17.662 19.708">
													<path d="M-380.03-1782.005a7.881,7.881,0,0,1,7.873-7.872,7.882,7.882,0,0,1,7.873,7.872,7.882,7.882,0,0,1-7.873,7.873A7.882,7.882,0,0,1-380.03-1782.005Zm3.766,0a4.111,4.111,0,0,0,4.107,4.107,4.111,4.111,0,0,0,4.107-4.107,4.111,4.111,0,0,0-4.107-4.107A4.111,4.111,0,0,0-376.264-1782.005Zm-4.682-7.925v-2.91h3.767v2.91Z" transform="translate(381.446 1793.341)" />
												</svg>
												<div class="cli_name">Threads ME Store</div>
											</label>
										</li>

										<li class="asd" data-tab="4">
											<input type="radio" id="tab4" name="tabs" />
											<label class="tab" for="tab4">
												<svg xmlns="http://www.w3.org/2000/svg" width="17.662" height="19.708" viewBox="0 0 17.662 19.708">
													<path d="M-380.03-1782.005a7.881,7.881,0,0,1,7.873-7.872,7.882,7.882,0,0,1,7.873,7.872,7.882,7.882,0,0,1-7.873,7.873A7.882,7.882,0,0,1-380.03-1782.005Zm3.766,0a4.111,4.111,0,0,0,4.107,4.107,4.111,4.111,0,0,0,4.107-4.107,4.111,4.111,0,0,0-4.107-4.107A4.111,4.111,0,0,0-376.264-1782.005Zm-4.682-7.925v-2.91h3.767v2.91Z" transform="translate(381.446 1793.341)" />
												</svg>
												<div class="cli_name">Levo Exhibitions</div>
											</label>
										</li>


										<li class="asd" data-tab="5">
											<input type="radio" id="tab5" name="tabs" />
											<label class="tab" for="tab5">
												<svg xmlns="http://www.w3.org/2000/svg" width="17.662" height="19.708" viewBox="0 0 17.662 19.708">
													<path d="M-380.03-1782.005a7.881,7.881,0,0,1,7.873-7.872,7.882,7.882,0,0,1,7.873,7.872,7.882,7.882,0,0,1-7.873,7.873A7.882,7.882,0,0,1-380.03-1782.005Zm3.766,0a4.111,4.111,0,0,0,4.107,4.107,4.111,4.111,0,0,0,4.107-4.107,4.111,4.111,0,0,0-4.107-4.107A4.111,4.111,0,0,0-376.264-1782.005Zm-4.682-7.925v-2.91h3.767v2.91Z" transform="translate(381.446 1793.341)" />
												</svg>
												<div class="cli_name">Emerald Events and Exhibitions</div>
											</label>
										</li>

										<li class="glider"></li>

									</ul>


								</div>
							</div>

						</div>



						<div class="def_btn" data-sal="slide-up" data-sal-duration="500" data-sal-delay="200">
							<a href="javascript:void(0);">
								<span>دعنا نتحدث اليوم</span>
							</a>
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>


	<section id="our_solution">
		<div class="container">
			<div class="row">

				<div class="tit_le center-align" data-sal="slide-up" data-sal-duration="500" data-sal-delay="300">
					<div class="lkasjdw">اختر حلول براندي</div>
					<h1>لنلبي احتياجات شركتك</h1>
				</div>


				<div class="alsdewpflo center-align">
					<ul class="inline-block">
						<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="500">
							<div class="dmalksdw">
								<img src="img/business_website.svg">
							</div>
							<span>
								موقع خدماتي
							</span>
						</li>

						<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="700">
							<div class="dmalksdw">
								<img src="img/ecommerce_website.svg">
							</div>
							<span>
								موقع للتجارة الالكترونية
							</span>
						</li>

						<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="900">
							<div class="dmalksdw">
								<img src="img/personal_website.svg">
							</div>
							<span>
								موقع شخصي
							</span>
						</li>
					</ul>
				</div>


			</div>
		</div>
	</section>


	<section id="oklsdi">
		<div class="container">
			<div class="row">

				<div class="col l7 m12 s12">
					<div class="askldepdfe">
						<div class="tit_le" data-sal="slide-up" data-sal-duration="500" data-sal-delay="300">
							<div class="lkasjdw">انتقل إلى العمل الرقمي وبمظهر مميز</div>
							<h1>سارع في نمو أعمالك مع حلولنا الرقمية!</h1>
						</div>

						<ul class="asldkjeoiff">
							<li data-sal="slide-left" data-sal-duration="500" data-sal-delay="500">
								<div class="lksjr">
									<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20.141" viewBox="0 0 20 20.141">
										<g transform="translate(-2 -2)">
											<line x2="8.4" transform="translate(12 9)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<line x2="8.4" transform="translate(14.598 13.5) rotate(120)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<line x2="8.4" transform="translate(9.402 13.5) rotate(-120)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<circle cx="3" cy="3" r="3" transform="translate(9 9)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<circle cx="9" cy="9" r="9" transform="translate(3 3)" fill="none" stroke="#555151" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
										</g>
									</svg>
								</div>
								<div class="ni_tit">
									الظهور على شبكة الانترنت
								</div>
							</li>

							<li data-sal="slide-left" data-sal-duration="500" data-sal-delay="600">
								<div class="lksjr">
									<svg xmlns="http://www.w3.org/2000/svg" width="18" height="20" viewBox="0 0 18 20">
										<g transform="translate(-3 -2)">
											<line x2="5" transform="translate(4 8)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<line x2="5" transform="translate(15 8)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<path d="M4,13V5A2,2,0,0,1,6,3H7A2,2,0,0,1,9,5v8a3,3,0,0,0,6,0V5a2,2,0,0,1,2-2h1a2,2,0,0,1,2,2v8A8,8,0,0,1,4,13" fill="none" stroke="#555151" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
										</g>
									</svg>
								</div>
								<div class="ni_tit">
									جذب العملاء المحتملين
								</div>
							</li>

							<li data-sal="slide-left" data-sal-duration="500" data-sal-delay="700">
								<div class="lksjr">
									<svg xmlns="http://www.w3.org/2000/svg" width="20.332" height="20.299" viewBox="0 0 20.332 20.299">
										<g transform="translate(-1.684 -2.017)">
											<path d="M3,21l1.65-3.8a9,9,0,1,1,3.4,2.9L3,21" fill="none" stroke="#555151" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<path d="M9,10a.5.5,0,0,0,1,0V9A.5.5,0,0,0,9,9v1a5,5,0,0,0,5,5h1a.5.5,0,0,0,0-1H14a.5.5,0,0,0,0,1" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
										</g>
									</svg>
								</div>
								<div class="ni_tit">
									ربط الموقع بالواتس آب
								</div>
							</li>

							<li data-sal="slide-left" data-sal-duration="500" data-sal-delay="800">
								<div class="lksjr">
									<svg xmlns="http://www.w3.org/2000/svg" width="20" height="21" viewBox="0 0 20 21">
										<g transform="translate(-2 -2)">
											<circle cx="1" cy="1" r="1" transform="translate(9 20)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<circle cx="1" cy="1" r="1" transform="translate(16 20)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<path d="M3,3H5L7,15a3,3,0,0,0,3,2h7a3,3,0,0,0,3-2l1-7H5.8" fill="none" stroke="#555151" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
										</g>
									</svg>
								</div>
								<div class="ni_tit">
								 التسوّق الالكتروني
								</div>
							</li>

							<li data-sal="slide-left" data-sal-duration="500" data-sal-delay="900">
								<div class="lksjr">
									<svg xmlns="http://www.w3.org/2000/svg" width="20" height="16" viewBox="0 0 20 16">
										<g transform="translate(-2 -4)">
											<line x2="18" transform="translate(3 10)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<line x2="0.01" transform="translate(7 15)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<line x2="4" transform="translate(10 15)" fill="none" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<rect width="18" height="14" rx="3" transform="translate(3 5)" fill="none" stroke="#555151" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
										</g>
									</svg>
								</div>
								<div class="ni_tit">
									الدفع الالكتروني
								</div>
							</li>

							<li data-sal="slide-left" data-sal-duration="500" data-sal-delay="1000">
								<div class="lksjr">
									<svg xmlns="http://www.w3.org/2000/svg" width="19.771" height="19.971" viewBox="0 0 19.771 19.971">
										<g transform="translate(-2.029 -2)">
											<path d="M10,3.2A9,9,0,1,0,20.8,14a1,1,0,0,0-1-1H13a2,2,0,0,1-2-2V4a.9.9,0,0,0-1-.8" fill="none" stroke="#555151" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
											<path d="M15,3.5A9,9,0,0,1,20.5,9H16a1,1,0,0,1-1-1V3.5" fill="#2376ba" stroke="#2376ba" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" />
										</g>
									</svg>
								</div>
								<div class="ni_tit">
									التحليل والتقارير اليومية
								</div>
							</li>
						</ul>


					</div>

				</div>

				<div class="col l5 m12 s12 hide-on-med-and-down">
					<div class="alksdepr" data-sal="slide-up" data-sal-duration="500" data-sal-delay="100">
						<img src="img/sapiens4.svg">
					</div>
				</div>

			</div>
		</div>
	</section>


	<section id="cta_sm">
		<div class="container">
			<div class="row">

				<div class="col s12">
					<div class="klasdje_ds" data-sal="slide-up" data-sal-duration="500" data-sal-delay="200">
						<h1>دعنا نبني لك موقعك لتبدأ تجارتك الإلكترونية</h1>
					</div>
				</div>

			</div>
		</div>
	</section>


	<section id="about_us">
		<div class="container">
			<div class="row">
				<div class="col s12">
					<div class="askjdered">

						<div class="tit_le center-align" data-sal="slide-up" data-sal-duration="500" data-sal-delay="300">
							<div class="lkasjdw">براندي</div>
							<h1> تصميم وبراندنج في الامارات والسعودية يمكن أن تمنح الحياة لعلامتك التجارية!</h1>
						</div>

						<div class="kasnkde_ds center-align" data-sal="slide-up" data-sal-duration="500" data-sal-delay="500">
							<p>
في براندي، نجمع بين الإبداع وأحدث التطورات الرقمية لتقديم خدمات يمكنها تجديد علامتك التجارية والارتقاء بها إلى آفاق جديدة من النجاح. منذ تأسيسنا، عملنا مع شركات من جميع الأنواع والأحجام، وساعدنا في بناء العديد من العلامات التجارية الناجحة التي تجمع بين عناصر الجمال والابداع.
							</p>
						</div>

					</div>
				</div>
			</div>
		</div>
	</section>


	<section id="our_clients">
		<div class="container">
			<div class="row center-align">

				<div class="tit_le" data-sal="slide-up" data-sal-duration="100" data-sal-delay="100">
					<div class="lkasjdw">عملاؤنا</div>
					<h1>يحدونا كل الفخر ونحن نعمل من أجل</h1>
				</div>

				<ul class="kjhsdfclie inline-block">
					<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="300">
						<div class="oids">
							<img src="img/clients/belhasa.png">
						</div>
					</li>
					<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="400">
						<div class="oids">
							<img src="img/clients/medcare.svg">
						</div>
					</li>
					<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="500">
						<div class="oids">
							<img src="img/clients/aster.png">
						</div>
					</li>
					<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="600">
						<div class="oids">
							<img src="img/clients/body-shop.png">
						</div>
					</li>
					<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="700">
						<div class="oids">
							<img src="img/clients/mashreq.png">
						</div>
					</li>
					<li data-sal="slide-up" data-sal-duration="500" data-sal-delay="800">
						<div class="oids">
							<img src="img/clients/productive.svg">
						</div>
					</li>
				</ul>

			</div>
		</div>
	</section>



	<section id="get_touch">
		<div class="container">
			<div class="row">

				<div class="alfsder_tit center-align" data-sal="slide-up" data-sal-duration="500" data-sal-delay="300">
					<h1>تواصل معنا اليوم</h1>
					<div class="mlkl">جميع القنوات للتواصل</div>
				</div>


				<div class="clpo">
					<ul>
						<li data-sal="slide-left" data-sal-duration="500" data-sal-delay="500">
							<h3 class="ti_le">تواصل معنا</h3>
							<a href="tel:+971 52 1104087">+971 52 1104087</a>
							<a href="mailto:info@thedesignhub.ae">hello@brande.ae</a>
						</li>

						<li data-sal="slide-left" data-sal-duration="500" data-sal-delay="700">
							<h3 class="ti_le">دبي</h3>
							<p>
								2202/2203, <br>
								جي بي سي ١ - مقاطعة ج <br>
								أبراج بحيرات جميرا، دبي. <br>
								الامارات العربية المتحدة
							</p>
						</li>

						<li data-sal="slide-left" data-sal-duration="500" data-sal-delay="900">
							<h3 class="ti_le">أبوظبي</h3>
							<p>
								902ب, تو فور 54 بناية 6, <br>
								شارع الشيخ زايد, <br>
								أبوظبي. <br>
								الامارات العربية المتحدة
							</p>
						</li>

					</ul>
				</div>

			</div>
		</div>
	</section>



	<div id="mobile_menu">
		<div class="m_menu_header">

			<div class="lef_sec">
				<div id="menu_but">
					<svg xmlns="http://www.w3.org/2000/svg" width="30.75" height="20.5" viewBox="0 0 30.75 20.5">
						<path d="M4.5,29.5H35.25V26.083H4.5Zm0-8.542H35.25V17.542H4.5ZM4.5,9v3.417H35.25V9Z" transform="translate(-4.5 -9)" />
					</svg>
				</div>

				<div class="head_logo">
					<a href="javascript:void(0);">
						<img src="img/Brande-Logo.png">
					</a>
				</div><!-- head_logo -->
			</div><!-- lef_sec -->

			<div class="righ_sec">
				<div class="def_btn sal-animate" data-sal="slide-up" data-sal-duration="500" data-sal-delay="200">
					<a href="javascript:void(0);">
						<span>دعنا نتحدث اليوم</span>
					</a>
				</div>
			</div>

		</div><!-- m_menu_header -->



		<div class="sid_menu">
			<div class="si_hed">
				<div id="close_ope">
					<svg xmlns="http://www.w3.org/2000/svg" width="21" height="21" viewBox="0 0 21 21">
						<path d="M28.5,9.615,26.385,7.5,18,15.885,9.615,7.5,7.5,9.615,15.885,18,7.5,26.385,9.615,28.5,18,20.115,26.385,28.5,28.5,26.385,20.115,18Z" transform="translate(-7.5 -7.5)" />
					</svg>
				</div><!-- close_ope -->
				<div class="si_logo">
					<a href="javascript:void(0);">
						<img src="img/Brande-Logo.png">
					</a>
				</div><!-- si_logo -->
			</div><!-- si_hed -->


			<div id="si_ma_menu">

				<div id="menu-main-menu" class="main-nav">
					<ul class="mob">
						<li><a href="#main_slider">الرئيسية</a></li>
						<li><a href="#oklsdi">خدمات الويب</a></li>
						<li><a href="#free_offer">العرض الحالي</a></li>
						<li><a href="#about_us">من نحن</a></li>
						<li><a href="#get_touch">اتصل بنا</a></li>
						<li><a href="javascript:void(0);" id="new_proj">دعنا نتحدث اليوم</a></li>
					</ul>
				</div>

			</div><!-- si_ma_menu -->

		</div><!-- sid_menu -->

		<div class="act_si_menu" style="display: none;"></div><!-- shadow -->
	</div><!-- mobile_menu -->


	<div class="show-popup-ask-close">
		<div id="close_p">
			<svg version="1.1" id="Capa_1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px" width="357px" height="357px" viewBox="0 0 357 357" style="enable-background:new 0 0 357 357;" xml:space="preserve">
				<g>
					<g id="close">
						<polygon points="357,35.7 321.3,0 178.5,142.8 35.7,0 0,35.7 142.8,178.5 0,321.3 35.7,357 178.5,214.2 321.3,357 357,321.3 214.2,178.5 " />
					</g>
				</g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
				<g></g>
			</svg>
		</div>


		<form class="contact-form" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
			<?php if (!empty($formErrors)) { ?>
				<div class="alert alert-danger alert-dismissible" role="start">
					<?php
					foreach ($formErrors as $error) {
						echo $error . '<br/>';
					}
					?>
				</div>
			<?php } ?>
			<?php if (isset($success)) {
				echo $success;
			} ?>
			<div class="form-group">
				<input class="username form-control" type="text" name="username" placeholder="الاسم" value="<?php if (isset($user)) {
																													echo $user;
																												} ?>" />
			</div>
			<div class="form-group">
				<input class="email form-control" type="email" name="email" placeholder="البريد الالكتروني" value="<?php if (isset($mail)) {
																													echo $mail;
																												} ?>" />
			</div>

			<div class="form-group">
				<input class="phone form-control" type="text" name="cellphone" placeholder="رقم الهاتف" value="<?php if (isset($cell)) {
																														echo $cell;
																													} ?>" />
			</div>

			<input class="btn btn-success" type="submit" value="ارسل" />
		</form>

	</div>

	<div class="popup-overlay"></div>

	<a href="https://api.whatsapp.com/send?phone=971521104087" target="_blank" class="whatsapp_sec"> <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 512 512" xml:space="preserve">
			<path style="fill:#fff;" d="M256.064,0h-0.128l0,0C114.784,0,0,114.816,0,256c0,56,18.048,107.904,48.736,150.048l-31.904,95.104  l98.4-31.456C155.712,496.512,204,512,256.064,512C397.216,512,512,397.152,512,256S397.216,0,256.064,0z"></path>
			<path style="fill:#26d367;" d="M405.024,361.504c-6.176,17.44-30.688,31.904-50.24,36.128c-13.376,2.848-30.848,5.12-89.664-19.264  C189.888,347.2,141.44,270.752,137.664,265.792c-3.616-4.96-30.4-40.48-30.4-77.216s18.656-54.624,26.176-62.304  c6.176-6.304,16.384-9.184,26.176-9.184c3.168,0,6.016,0.16,8.576,0.288c7.52,0.32,11.296,0.768,16.256,12.64  c6.176,14.88,21.216,51.616,23.008,55.392c1.824,3.776,3.648,8.896,1.088,13.856c-2.4,5.12-4.512,7.392-8.288,11.744  c-3.776,4.352-7.36,7.68-11.136,12.352c-3.456,4.064-7.36,8.416-3.008,15.936c4.352,7.36,19.392,31.904,41.536,51.616  c28.576,25.44,51.744,33.568,60.032,37.024c6.176,2.56,13.536,1.952,18.048-2.848c5.728-6.176,12.8-16.416,20-26.496  c5.12-7.232,11.584-8.128,18.368-5.568c6.912,2.4,43.488,20.48,51.008,24.224c7.52,3.776,12.48,5.568,14.304,8.736  C411.2,329.152,411.2,344.032,405.024,361.504z"></path>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
			<g></g>
		</svg> <span>راسلنا عبر الواتس اب</span> </a>


	<div id="toTop" style=""> <span> <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 256 256" style="max-width: 12px;height: auto;float: left;margin: 11px 15px 11px 15px;" xml:space="preserve" width="512px" height="512px" class="">
				<g>
					<g>
						<g>
							<polygon points="128,48.907 0,176.907 30.187,207.093 128,109.28 225.813,207.093 256,176.907" data-original="#000000" class="active-path" data-old_color="#000000" fill="#FFFFFF"></polygon>
						</g>
					</g>
				</g>
			</svg> </span></div>


	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js" integrity="sha512-bLT0Qm9VnAYZDflyKcBaQ2gg0hSYNQrJ8RilYldYQ1FxQYoCLtUjuuRuZo+fjqhx/qtq/1itJ0C2ejDxltZVFg==" crossorigin="anonymous"></script>
	<script src="main.js"></script>

</body>

</html>