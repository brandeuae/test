/*
	Main Js file
*/
// Sal.js
// scroll animation library
!function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==typeof define&&define.amd?define([],t):"object"==typeof exports?exports.sal=t():e.sal=t()}(this,(function(){return function(e){var t={};function n(r){if(t[r])return t[r].exports;var o=t[r]={i:r,l:!1,exports:{}};return e[r].call(o.exports,o,o.exports,n),o.l=!0,o.exports}return n.m=e,n.c=t,n.d=function(e,t,r){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:r})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var r=Object.create(null);if(n.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)n.d(r,o,function(t){return e[t]}.bind(null,o));return r},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="dist/",n(n.s=0)}([function(e,t,n){"use strict";n.r(t);n(1);function r(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);t&&(r=r.filter((function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable}))),n.push.apply(n,r)}return n}function o(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{};t%2?r(Object(n),!0).forEach((function(t){i(e,t,n[t])})):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):r(Object(n)).forEach((function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))}))}return e}function i(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}var a="Sal was not initialised! Probably it is used in SSR.",s="Your browser does not support IntersectionObserver!\nGet a polyfill from here:\nhttps://github.com/w3c/IntersectionObserver/tree/master/polyfill",l={rootMargin:"0% 50%",threshold:.5,animateClassName:"sal-animate",disabledClassName:"sal-disabled",enterEventName:"sal:in",exitEventName:"sal:out",selector:"[data-sal]",once:!0,disabled:!1},c=[],u=null,f=function(e){e&&e!==l&&(l=o(o({},l),e))},d=function(e){e.classList.remove(l.animateClassName)},b=function(e,t){var n=new CustomEvent(e,{bubbles:!0,detail:t});t.target.dispatchEvent(n)},p=function(){document.body.classList.add(l.disabledClassName)},m=function(){u.disconnect(),u=null},y=function(){return l.disabled||"function"==typeof l.disabled&&l.disabled()},v=function(e,t){e.forEach((function(e){var n=e.target,r=void 0!==n.dataset.salRepeat,o=void 0!==n.dataset.salOnce,i=r||!(o||l.once);e.intersectionRatio>=l.threshold?(!function(e){e.target.classList.add(l.animateClassName),b(l.enterEventName,e)}(e),i||t.unobserve(n)):i&&function(e){d(e.target),b(l.exitEventName,e)}(e)}))},O=function(){p(),m()},g=function(){document.body.classList.remove(l.disabledClassName),u=new IntersectionObserver(v,{rootMargin:l.rootMargin,threshold:l.threshold}),(c=[].filter.call(document.querySelectorAll(l.selector),(function(e){return!function(e){return e.classList.contains(l.animateClassName)}(e,l.animateClassName)}))).forEach((function(e){return u.observe(e)}))},h=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:{};m(),Array.from(document.querySelectorAll(l.selector)).forEach(d),f(e),g()};t.default=function(){var e=arguments.length>0&&void 0!==arguments[0]?arguments[0]:l;if(f(e),"undefined"==typeof window)return console.warn(a),{elements:c,disable:O,enable:g,reset:h};if(!window.IntersectionObserver)throw p(),Error(s);return y()?p():g(),{elements:c,disable:O,enable:g,reset:h}}},function(e,t,n){}]).default}));

/*
// Darkmode
!function(e,t){"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==typeof define&&define.amd?define("darkmode-js",[],t):"object"==typeof exports?exports["darkmode-js"]=t():e["darkmode-js"]=t()}("undefined"!=typeof self?self:this,(function(){return function(e){var t={};function n(o){if(t[o])return t[o].exports;var r=t[o]={i:o,l:!1,exports:{}};return e[o].call(r.exports,r,r.exports,n),r.l=!0,r.exports}return n.m=e,n.c=t,n.d=function(e,t,o){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:o})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var o=Object.create(null);if(n.r(o),Object.defineProperty(o,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var r in e)n.d(o,r,function(t){return e[t]}.bind(null,r));return o},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=0)}([function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0;var o=function(e){if(e&&e.__esModule)return e;var t={};if(null!=e)for(var n in e)if(Object.prototype.hasOwnProperty.call(e,n)){var o=Object.defineProperty&&Object.getOwnPropertyDescriptor?Object.getOwnPropertyDescriptor(e,n):{};o.get||o.set?Object.defineProperty(t,n,o):t[n]=e[n]}return t.default=e,t}(n(1));var r=o.default;t.default=r,o.IS_BROWSER&&function(e){e.Darkmode=o.default}(window),e.exports=t.default},function(e,t,n){"use strict";function o(e,t){for(var n=0;n<t.length;n++){var o=t[n];o.enumerable=o.enumerable||!1,o.configurable=!0,"value"in o&&(o.writable=!0),Object.defineProperty(e,o.key,o)}}Object.defineProperty(t,"__esModule",{value:!0}),t.default=t.IS_BROWSER=void 0;var r="undefined"!=typeof window;t.IS_BROWSER=r;var a=function(){function e(t){if(function(e,t){if(!(e instanceof t))throw new TypeError("Cannot call a class as a function")}(this,e),r){t=Object.assign({},{bottom:"32px",right:"32px",left:"unset",time:"0.3s",mixColor:"#fff",backgroundColor:"#fff",buttonColorDark:"#100f2c",buttonColorLight:"#fff",label:"",saveInCookies:!0,autoMatchOsTheme:!0},t);var n="\n      .darkmode-layer {\n        position: fixed;\n        pointer-events: none;\n        background: ".concat(t.mixColor,";\n        transition: all ").concat(t.time," ease;\n        mix-blend-mode: difference;\n      }\n\n      .darkmode-layer--button {\n        width: 2.9rem;\n        height: 2.9rem;\n        border-radius: 50%;\n        right: ").concat(t.right,";\n        bottom: ").concat(t.bottom,";\n        left: ").concat(t.left,";\n      }\n\n      .darkmode-layer--simple {\n        width: 100%;\n        height: 100%;\n        top: 0;\n        left: 0;\n        transform: scale(1) !important;\n      }\n\n      .darkmode-layer--expanded {\n        transform: scale(100);\n        border-radius: 0;\n      }\n\n      .darkmode-layer--no-transition {\n        transition: none;\n      }\n\n      .darkmode-toggle {\n        background: ").concat(t.buttonColorDark,";\n        width: 3rem;\n        height: 3rem;\n        position: fixed;\n        border-radius: 50%;\n        border:none;\n        right: ").concat(t.right,";\n        bottom: ").concat(t.bottom,";\n        left: ").concat(t.left,";\n        cursor: pointer;\n        transition: all 0.5s ease;\n        display: flex;\n        justify-content: center;\n        align-items: center;\n      }\n\n      .darkmode-toggle--white {\n        background: ").concat(t.buttonColorLight,";\n      }\n\n      .darkmode-toggle--inactive {\n        display: none;\n      }\n\n      .darkmode-background {\n        background: ").concat(t.backgroundColor,";\n        position: fixed;\n        pointer-events: none;\n        z-index: -10;\n        width: 100%;\n        height: 100%;\n        top: 0;\n        left: 0;\n      }\n\n      img, .darkmode-ignore {\n        isolation: isolate;\n        display: inline-block;\n      }\n\n      @media screen and (-ms-high-contrast: active), (-ms-high-contrast: none) {\n        .darkmode-toggle {display: none !important}\n      }\n\n      @supports (-ms-ime-align:auto), (-ms-accelerator:true) {\n        .darkmode-toggle {display: none !important}\n      }\n    "),o=document.createElement("div"),a=document.createElement("button"),i=document.createElement("div");a.innerHTML=t.label,a.classList.add("darkmode-toggle--inactive"),o.classList.add("darkmode-layer"),i.classList.add("darkmode-background");var d="true"===window.localStorage.getItem("darkmode"),s=t.autoMatchOsTheme&&window.matchMedia("(prefers-color-scheme: dark)").matches,l=null===window.localStorage.getItem("darkmode");(!0===d&&t.saveInCookies||l&&s)&&(o.classList.add("darkmode-layer--expanded","darkmode-layer--simple","darkmode-layer--no-transition"),a.classList.add("darkmode-toggle--white"),document.body.classList.add("darkmode--activated")),document.body.insertBefore(a,document.body.firstChild),document.body.insertBefore(o,document.body.firstChild),document.body.insertBefore(i,document.body.firstChild),this.addStyle(n),this.button=a,this.layer=o,this.saveInCookies=t.saveInCookies,this.time=t.time}}var t,n,a;return t=e,(n=[{key:"addStyle",value:function(e){var t=document.createElement("link");t.setAttribute("rel","stylesheet"),t.setAttribute("type","text/css"),t.setAttribute("href","data:text/css;charset=UTF-8,"+encodeURIComponent(e)),document.head.appendChild(t)}},{key:"showWidget",value:function(){var e=this;if(r){var t=this.button,n=this.layer,o=1e3*parseFloat(this.time);t.classList.add("darkmode-toggle"),t.classList.remove("darkmode-toggle--inactive"),t.setAttribute("aria-label","Activate dark mode"),t.setAttribute("aria-checked","false"),t.setAttribute("role","checkbox"),n.classList.add("darkmode-layer--button"),t.addEventListener("click",(function(){var r=e.isActivated();r?(n.classList.remove("darkmode-layer--simple"),t.setAttribute("disabled",!0),setTimeout((function(){n.classList.remove("darkmode-layer--no-transition"),n.classList.remove("darkmode-layer--expanded"),t.removeAttribute("disabled")}),1)):(n.classList.add("darkmode-layer--expanded"),t.setAttribute("disabled",!0),setTimeout((function(){n.classList.add("darkmode-layer--no-transition"),n.classList.add("darkmode-layer--simple"),t.removeAttribute("disabled")}),o)),t.classList.toggle("darkmode-toggle--white"),document.body.classList.toggle("darkmode--activated"),window.localStorage.setItem("darkmode",!r)}))}}},{key:"toggle",value:function(){if(r){var e=this.layer,t=this.isActivated(),n=this.button;e.classList.toggle("darkmode-layer--simple"),document.body.classList.toggle("darkmode--activated"),window.localStorage.setItem("darkmode",!t),n.setAttribute("aria-label","De-activate dark mode"),n.setAttribute("aria-checked","true")}}},{key:"isActivated",value:function(){return r?document.body.classList.contains("darkmode--activated"):null}}])&&o(t.prototype,n),a&&o(t,a),e}();t.default=a}])}));


//
const options = {
  bottom: '64px', // default: '32px'
  right: 'unset', // default: '32px'
  left: '32px', // default: 'unset'
  time: '0.5s', // default: '0.3s'
  mixColor: '#fff', // default: '#fff'
  backgroundColor: '#fff',  // default: '#fff'
  buttonColorDark: '#100f2c',  // default: '#100f2c'
  buttonColorLight: '#fff', // default: '#fff'
  saveInCookies: false, // default: true,
  label: '🌓', // default: ''
  autoMatchOsTheme: true // default: true
}

const darkmode = new Darkmode(options);
darkmode.showWidget();
*/



// Header Scroll
(function(){

  var doc = document.documentElement;
  var w = window;

  var prevScroll = w.scrollY || doc.scrollTop;
  var curScroll;
  var direction = 0;
  var prevDirection = 0;

  var header = document.getElementById('site_header');

  var checkScroll = function() {

    /*
    ** Find the direction of scroll
    ** 0 - initial, 1 - up, 2 - down
    */

    curScroll = w.scrollY || doc.scrollTop;
    if (curScroll > prevScroll) { 
      //scrolled up
      direction = 2;
    }
    else if (curScroll < prevScroll) { 
      //scrolled down
      direction = 1;
    }

    if (direction !== prevDirection) {
      toggleHeader(direction, curScroll);
    }
    
    prevScroll = curScroll;
  };

  var toggleHeader = function(direction, curScroll) {
    if (direction === 2 && curScroll > 90) { 
      
      //replace 90 with the height of your header in px

      header.classList.add('scr_lled');
      prevDirection = direction;
    }
    else if (direction === 1) {
      header.classList.remove('scr_lled');
      prevDirection = direction;
    }
  };
  
  window.addEventListener('scroll', checkScroll);

})();


$(window).scroll(function() {    
    var scroll = $(window).scrollTop();

    if (scroll >= 90) {
        $("header").addClass("darkHeader");
    } else {
        $("header").removeClass("darkHeader");
    }
});


// Go top
//Check to see if the window is top if not then display button
$(window).scroll(function(){
    if ($(this).scrollTop() > 100) {
        $('#toTop').fadeIn("fast");
    } else {
        $('#toTop').fadeOut();
    }
});

//Click event to scroll to top
$('#toTop').click(function(){
    $('html, body').animate({scrollTop : 0},250);
    return false;
});


// Scroll Animation
$(document).ready(function(){

  sal({
    // rootMargin: '0% 50%',
    threshold: 0.3, // 50%
    animateClassName: 'sal-animate',
    disabledClassName: 'sal-disabled',
    selector: '[data-sal]',
    once: true, // run only once
    disabled: false,
    // enterEventName: 'sal:in'
    // exitEventName: 'sal:out'
  });

});


// Projects Tabs
$(document).ready(function() {

  // Change tab class and display content
  $('div.tab-content').not('[data-tab=1]').addClass('hide_en');
  $('div.tab-content').first().addClass('dis_play');

  $('.tabs li').first().addClass('active');
  $('.tabs li').on('click', function() {
  $(this).addClass("active");
  $('.tabs li').not(this).removeClass('active');


  //start sort
  var sortable = $(this).attr('data-tab');
    $('div[data-tab = '+sortable+']').removeClass('hide_en');
    $('div[data-tab = '+sortable+']').addClass('dis_play');
    $('div.tab-content').not('[data-tab='+sortable+']').addClass('hide_en');
    $('div.tab-content').not('[data-tab='+sortable+']').removeClass('dis_play');
  });

  //add an all option - to show all tabs when clicked
  $('li[data-tab=all]').on('click', function() {
    $(this).addClass('active');
    $('div.tab-content').addClass('hide_en');
  });
  

  // Scroll to div
  $(document).on('click', 'a[href^="#"]', function (event) {
    event.preventDefault();

    $('html, body').animate({
        scrollTop: $($.attr(this, 'href')).offset().top
    }, 500);
  });



    // Mobile Menu
    // Display Search
    $("#menu_but, #close_ope, #si_ma_menu ul li a").on("mousedown", function(e) {
        $(".sid_menu").toggleClass("active_sid");
        $("body").toggleClass("ove_low");
        $(".act_si_menu").fadeToggle("fast");
    });


    // popup
     $(".def_btn a, #new_proj").click(function () {
        $(".popup-overlay").show();
        $(".show-popup-ask-close").show();
     });

     $("#close_p, .popup-overlay").click(function () {
         $(".show-popup-ask-close").hide();
         $('.popup-overlay').hide();
     });
   

    // Form
    /*global $, alert, console */
    $(function () {
       
        'use strict';

        var userError   = true,
            
            emailError  = true,
            
            msgError    = true;
        
        $('.username').blur(function () {
           
            if ($(this).val().length < 4) { // Show Error
                            
                $(this).css('border', '1px solid #F00').parent().find('.custom-alert').fadeIn(200)
                
                    .end().find('.asterisx').fadeIn(100);
                
                userError = true;
                
            } else { // No Errors
                            
                $(this).css('border', '1px solid #080').parent().find('.custom-alert').fadeOut(200)
                
                    .end().find('.asterisx').fadeOut(100);
                
                userError = false;
                
            }
            
        });
        
        $('.email').blur(function () {
           
            if ($(this).val() === '') {
                            
                $(this).css('border', '1px solid #F00').parent().find('.custom-alert').fadeIn(200)
                    
                    .end().find('.asterisx').fadeIn(100);
                            
                emailError = true;
                
            } else {
                            
                $(this).css('border', '1px solid #080').parent().find('.custom-alert').fadeOut(200)
                
                    .end().find('.asterisx').fadeOut(100);
                            
                emailError = false;
                
            }
            
        });
        
        $('.phone').blur(function () {
           
            if ($(this).val().length < 2) {
                
                $(this).css('border', '1px solid #F00').parent().find('.custom-alert').fadeIn(200)
                    
                    .end().find('.asterisx').fadeIn(100);
                
                msgError = true;
                
            } else {
                            
                $(this).css('border', '1px solid #080').parent().find('.custom-alert').fadeOut(200)
                    
                    .end().find('.asterisx').fadeOut(100);
                
                msgError = false;
                
            }
            
        });
       
        // Submit Form Validation
        $('.contact-form').submit(function (e) {
            
            if (userError === true || emailError === true || msgError === true) {
                
                e.preventDefault();
                
                $('.username, .email, .phone').blur();
                
            }
            
        });
        
    });


});


